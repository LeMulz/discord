fx_version 'adamant'

game 'gta5'

author 'Reza_Cyber'

description 'Discord Action Buttons . Developed By https://discord.gg/hjgphuxarE'

shared_script 'Config.lua'
client_script 'Client.lua'
