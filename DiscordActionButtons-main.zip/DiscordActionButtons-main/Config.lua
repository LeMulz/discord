Config = {}
Config.Buttons = {
    {index = 0,name = '%WDiscord%',url = 'https://discord.gg/4Nv8ANEQXG'},
    {index = 1,name = '%Connect%',url = 'connect 148.251.5.4:30866'}
}